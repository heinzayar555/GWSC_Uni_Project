<?php
  session_start();
if(!empty($_SESSION['type']))
{
  header('location:../index.php');
}
?>