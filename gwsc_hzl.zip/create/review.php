<?php
    require_once('../db/dbconfig.php');
    $name = $_POST['r_name'];
    $msg = $_POST['r_msg'];
    $img = $_POST['r_img'];
    $star = $_POST['r_star'];

    $review_statement = "INSERT INTO review(r_name,r_msg,r_img,r_star) VALUES (:r_name,:r_msg,:r_img,:r_star)";
    $review_statement = $pdo_conn->prepare($review_statement);
    $review_statement->execute(array(':r_name'=>$name,':r_msg'=>$msg,':r_img'=>$img,':r_star'=>$star));
    header('location:../reviews.php');
?>