<?php
  require_once('header.php');
  require_once('db/dbconfig.php');


?>

<section class="mb-1">
<div id="carouselExampleDark" class="carousel carousel-dark slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" data-bs-interval="10000">
      <img src="images/feature1.jpg" class="d-block w-100" alt="feature">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="text-white">Pool Floats</h5>
        <p class="text-white">Intended for swimmers to relax</p>
      </div>
    </div>
    <div class="carousel-item" data-bs-interval="2000">
      <img src="images/g10.jpg" class="d-block w-100" alt="feature">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="text-white">Water Ride</h5>
        <p class="text-white">Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/carparking1.jpg" class="d-block w-100" alt="feature">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="text-white">Car Parking</h5>
        <p class="text-white">Customers car parking is arranged properly.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>

<div class="container-fluid">
        <div class="row my-4">
            <div class="col-md-12">
            <a class="weatherwidget-io" href="https://forecast7.com/en/40d71n74d01/new-york/" data-label_1="NEW YORK" data-label_2="WEATHER" data-theme="original" >NEW YORK WEATHER</a>
<script>
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src='https://weatherwidget.io/js/widget.min.js';fjs.parentNode.insertBefore(js,fjs);}}(document,'script','weatherwidget-io-js');
</script>
            </div>
        </div>
</div>

<div class="container-fluid py-5 bg-secondary">
    <div class="row">
        <div class="col-md-4">
		<figure class="figure">
		<img src="images/feature3.jpg" style="width:100%; height: 90%;" class="figure-img img-fluid rounded" alt="feature">
		<p>Swimming is a well-liked activity for people looking to relax and de-stress because it can provide a variety of benefits for relaxation. While the repetitive motion of swimming can be meditative and calming for the mind, the sensation of weightlessness that comes with being in the water can help to reduce tension in the body.</p>
		</figure>
		</div>

        <div class="col-md-4">
		<figure class="figure">
		<img src="images/feature2.jpg" style="width:100%; height: 90%;" class="figure-img img-fluid rounded" alt="feature">
		<p>In addition to providing free internet access to its customers, GWSC may want to install Wi-Fi access on its website or collaborate with another internet service provider to do so in appropriate locations, such as well-liked wild swimming areas or close-by cafés or restaurants.</p>
		</figure>
        </div>

        <div class="col-md-4">
		<figure class="figure">
		<img src="images/feature4.jpg" style="width:100%; height: 90%;" class="figure-img img-fluid rounded" alt="feature">
		<p>The key to relaxing is deep breathing. Inhale deeply through your nose, then exhale slowly through your mouth. Let yourself relax by concentrating on each breath. Avoid contracting having a good muscles. Maintain a loose, fluid physique and allow it to float in the water. You may feel more at ease and at home in the water as a result.</p>
		</figure>
        </div>
    </div>
</div>



<section class="services py-5">
	<div class="container-fluid $cyan-300">
		<div class="row justify-content-center py-5">
			<div class="col-xl-6 col-lg-8">
				<div class="title text-center">
					<h2>Our Facilities</h2>
					<p>Global Wild Swimming and Camping facilities may vary depending on the location, but generally, they can include amenities such as camping sites, showers, toilets, picnic areas, fire pits, access to natural bodies of water for swimming</p>
					<div class="border"></div>
				</div>
			</div>
		</div>
		<div class="row no-gutters">

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0 bg-warning">
				<div class="service-block p-4 color-bg text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Camping Site</h4>
					<p>A swimming club's camping areas may vary, but they often provide a space for campers to set up their tents or leave their RVs for the night or longer. These campgrounds could provide the bare necessities, like showers and toilets as well as power, water, and garbage disposal.</p>
				</div>
			</div>

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
				<div class="service-block p-4 text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Showers, Toilets</h4>
					<p>For its members and visitors, most swimming clubs normally provide shower and restroom facilities. Swimmers may change and brighten up before and after using the pool thanks to these amenities, which are often found in a private men's bathroom next to the pool area.</p>
				</div>
			</div>

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0 bg-warning">
				<div class="service-block p-4 color-bg text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Picnic areas, Fire pits</h4>
					<p>Picnic spaces and fire pits may be included in swimming clubs' camping amenities. Campers can gather in picnic grounds, which are frequently furnished with picnic tables, grills, and shade shelters. Campfires are frequently made in fire pits, which can offer warmth on chilly nights.</p>
				</div>
			</div>

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
				<div class="service-block p-4  text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Access to natural bodies of water for swimming</h4>
					<p>Swimming clubs frequently provide its members access to lakes, rivers, and seas for swimming. Depending on the club, specific bathing places, docks, ladders, or platforms are also available for 
						accessing these bodies of water. </p>
				</div>
			</div>

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0 bg-warning">
				<div class="service-block p-4 color-bg text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Hiking trails</h4>
					<p>In addition to hiking paths, swimming clubs may also include other recreational amenities. Members and visitors can explore the natural surroundings and take in the area's picturesque charm through hiking routes.</p>
				</div>
			</div>

			<div class="col-lg-4 col-sm-6 mb-4 mb-lg-0">
				<div class="service-block p-4 text-center">
					<div class="service-icon text-center">
					</div>
					<h4>Guided tours</h4>
					<p>Swimming clubs may provide guided excursions as a part of their leisure offerings. Guided tours may be a fascinating and educational experience for members and guests, giving them insights into the neighborhood's history, flora, and fauna.</p>
				</div>
			</div>

		</div> 
	</div> 
</section> 

  <?php
require_once('footer.php');
?>
