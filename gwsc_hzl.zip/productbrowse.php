<?php
  require_once('header.php');
  require_once('db/dbconfig.php');
  
  $msg = "";
    if(isset($_GET['msg'])){
        $msg = $_GET['msg'];
    }

$searchErr = '';
$product_details='';
if(isset($_POST['save']))
{
    if(!empty($_POST['search']))
    {
        $search = $_POST['search'];
        $product = $pdo_conn->prepare("select * from product where (name like '%$search%' or description like '%$search%') and ava='0'");
        $product->execute();
        $product_browse = $product->fetchAll(PDO::FETCH_ASSOC);
         
    }
    else
    {
        $searchErr = "Please enter the information";
    }
    
}
?>


<section class="information py-5">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-dark text-center">Pitch Types and Availability</h1>
			</div>			
		</div>
	</div>
</section>

<section class="product py-5">
<div class="container-fluid">
<div class="col-md-10">
    <?php
            if($msg == "error")
            {
        ?>
            <div class="row">
                <div class="col-md-4 mx-auto mt-2">
                    <div class="alert alert-danger" role="alert">
                        <strong>Please Login your account.</strong>
                        <a href="login.php" class="but1 text-decoration-none f-300 btn btn-sm">Login Here!</a>
                    </div>

                </div>
            </div>
        <?php
            }
        ?>
  <div class="row">
  <?php
                if(!$product_browse)
                {
                  echo '<tr>No data found</tr>';
               }
               else{
                foreach($product_browse as $row){
              ?>     
    <div class="col-md-4 card-alg">
    <div class="card" style="width: 24rem;">
    <img src="images/<?php echo $row['image'];?>" class="card-img-top card-im" alt="...">
    <div class="card-body">
    <h5 class="card-title"><?php echo $row['name'];?></h5>
    <p class="card-text"><?php echo substr($row['description'], 0, 200) . "...";?></p>
    <p class="card-text">Price: $<?php echo $row['price'];?></p>
    <a href="service-detail.php?id=<?php echo $row['id'];?>" class="btn btn-primary">More Detail</a>
    <a href="book.php?id=<?php echo $row['id'];?>" class="btn btn-success">Book Now</a>
  </div>
</div>
</div>
<?php
        }
      }
?>
  </div>
</div>
</section>

<?php
require_once('footer.php');
?>
