<!doctype html>
<html lang="en">

<head>
  <title>Title</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
  <header>
    <nav class="navbar navbar-expand-sm navbar-light bg-light">
          <div class="container">
            <a class="navbar-brand" href="#">Admin</a>
            <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavId">
                <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php" aria-current="page">Dashboard </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="product/index.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="book/index.php">Bookings</a>
                    </li>
                </ul>
                <a href="index.php">
                    <?php
                        if(!empty($_SESSION['email']))
                        {
                    ?>
                        <a href="logout.php" class="list-group-item">  <i class="bi bi-person-circle"></i> <?= $_SESSION['name']; ?></a>
                    <?php
                        }
                        else{
                        echo 'Login';
                        }
                    ?>

              </a> 
            </div>
      </div>
    </nav>
    
  </header>