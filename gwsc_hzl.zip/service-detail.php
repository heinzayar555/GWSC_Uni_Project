<?php
    require_once('header.php'); 
    require_once('db/dbconfig.php');

    $id = $_GET['id'];
    $pdo_statement = $pdo_conn->prepare("SELECT product.* FROM product WHERE id='".$id."'");
    $pdo_statement->execute();
    $result = $pdo_statement->fetchAll();

    $msg = "";
    if(isset($_GET['msg'])){
        $msg = $_GET['msg'];
    }else{
        $msg = "";
    }

?>

<div class="col-md-12 mt-3">
<?php
                                if($msg == "error")
                                {
                            ?>
                                <div class="row">
                                    <div class="col-md-4 mx-auto text-center mt-2">
                                      <div class="alert alert-danger" role="alert">
                                          <strong>Please Login your account.</strong>
                                          <a href="backend/index.php" class="bg-primary text-white text-decoration-none btn btn-sm">Login Here!</a>
                                      </div>
                                    </div>
                                </div>
                            <?php
                                }
                            ?>
        <h3 class="text-center">PITCH DETAILS</h3>
          <div class="row">

              <?php
                if(!empty($result)){
                foreach($result as $row){
              ?>

                <div class="container">
                        <div class="row my-2">
                        <div class="col-md-5">
                            <img
                              src="images/<?php echo $row['image'];?>"
                              class="w-100 h-75 rounded shadow"
                              alt="service"
                            />
                          </div>
                          <div class="col-md-6 mt-3 me-3 mb-2">
                            <h4><?php echo $row['name'];?></h4>
                            <p class="card-text fw-bold mb-2">Price : $<?php echo $row['price'];?></p>
                            <p class="card-text text-justify"><?php echo $row['description'];?></p>
                            <?php 
                                for ($i=0; $i < $row['star']; $i++) { 
                                  echo '<i class="bi text-warning bi-star-fill"></i>';
                                }
                            ?>

                            <a href="book.php?id=<?php echo $row['id'];?>" class="ms-3 text-decoration-none f-600 btn btn-success btn-md">Book Now</a>
                          </div>
                        </div>
                      </div>

                <?php
                  }
                  }
                ?>
   
          </div>
      </div>