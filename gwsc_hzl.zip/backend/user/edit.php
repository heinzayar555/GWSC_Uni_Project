<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];

    $sql = $pdo_conn->prepare("SELECT * FROM users WHERE id=".$id);
    $sql->execute();
    $dataset = $sql->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Form</title>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.css' integrity='sha512-bR79Bg78Wmn33N5nvkEyg66hNg+xF/Q8NA8YABbj+4sBngYhv9P8eum19hdjYcY7vXk/vRkhM3v/ZndtgEXRWw==' crossorigin='anonymous'/>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php foreach ($dataset as $row) {
                ?>
                    <form action="update.php?id=<?php echo $row['id'];?>" method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">User Type</label>
                        <input type="number" class="form-control" placeholder="Update User Type" name="type"
                        value="<?php echo $row['type'];?>">
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" placeholder="Update Username"name="name" value="<?php echo $row['name'];?>">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Email Address</label>
                        <input type="email" class="form-control" placeholder="Update Email"name="email" value="<?php echo $row['email'];?>">
                    </div>
                    <div class="mb-3">
                        <label for="pasword" class="form-label">Password</label>
                        <input type="password" class="form-control" placeholder="Enter Password" name="password" value="<?php echo $row['pass'];?>">
                    </div>
                    <input type="submit" value="Update" class="btn btn-primary">
                    <a href="../dashboard.php" class=" ms-2 btn btn-danger text-white px-3 text-decoration-none">Cancel</a>
                </form>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>