<?php 
    include('../chklogin.php');
    include('../../db/dbconfig.php');
    $product_statement = $pdo_conn->prepare("SELECT * FROM product");
    $product_statement->execute();
    $product = $product_statement->fetchAll();
?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">


     <div class="container">
     <div class="row">
            <div class="col-md-12">    
                <h2 class="text-center">Products</h2>
                <a href="../dashboard.php" class=" bg-primary text-white p-2 text-decoration-none "><i class="fa fa-arrow-left"></i> Return Home </a>
            </div>
        </div>
    <div class="row col-md-12 col-md-offset-2 custyle mt-2">
    <table class="table table-striped custab">
    <thead>
        <tr>
            <th> <a href="createform.php" class="btn btn-success px-3 py-2">Create</a></th>
        </tr>

        <tr>
            <th>Pitch Name</th>
            <th>Image</th>
            <th>Type</th>
            <th>Description</th>
            <th>Price</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <?php   
                if(!empty($product)){
                foreach($product as $row){
            ?>
            <tr>
                <td><?= $row['name'];?></td>
                <td style="max-width:150px;">
                    <img src="../../images/<?php echo $row['image'];?>" class="w-100" alt="index">
		        </td>
                <td><?= $row['type_id'];?></td>
                <td style="max-width:100px;"><?= substr($row['description'], 0, 200);?></td>
                <td><?= $row['price'];?></td>
                <td class="text-center"><a class='btn btn-info btn-xs' href="edit.php?id=<?php echo $row['id'];?>"><span class="fa fa-edit"></span> Edit</a> <a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Del</a></td>
            </tr>

            <?php
                }
                }
            ?>

    </table>
    </div>
</div>
</div>


