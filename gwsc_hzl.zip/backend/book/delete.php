<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];
    
    $sql = $pdo_conn->prepare("DELETE FROM book WHERE id=".$id);
    $sql->execute();
    header('location:index.php');
?>