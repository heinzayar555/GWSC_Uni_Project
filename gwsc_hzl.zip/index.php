<?php
  require_once('header.php');
?>

<section class="mb-2">
<div id="carouselExampleCaptions" class="carousel slide">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/g1.jpg" class="d-block w-100" alt="swimming">
      <div class="carousel-caption d-none d-md-block">
        <h5>Competitions</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur dignissimos laborum consectetur totam error perspiciatis, explicabo autem aut eos laboriosam atque rerum, illo ullam excepturi delectus ipsum, nisi reiciendis! Optio?</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/g2.jpg" class="d-block w-100" alt="swimming">
      <div class="carousel-caption d-none d-md-block">
        <h5 class="text-dark">Social events</h5>
        <p class="text-dark">Swimming clubs often plan social gatherings like barbecues, parties, and excursions that give members a chance to get to know one another and foster a feeling of community.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/g3.jpg" class="d-block w-100" alt="swimming">
      <div class="carousel-caption d-none d-md-block">
         <h5>Open swim</h5>
         <p>Some clubs provide open swim times so that members can swim for fun and relaxation without the official framework of a training program.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</section>

<section id="about" class="about section-padding py-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-12 col-12">
        <div class="about-img">
          <img src="images/g4.jpg" alt="GWSC" class="img-fluid">
        </div>
      </div>
      <div class="col-lg-8 col-md-12 col-12 ps-lg-5 mt-md-5">
        <div class="about-text">
          <h2>GWSC Swimming Club</h2>
          <p>A group of people who are passionate about swimming come together to form a swimming club. The club's members join together for swimming-related events including social gatherings, tournaments, and regular training sessions. Members of the club get the chance to develop their swimming abilities and techniques as well as meet new people with similar interests.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="services section-padding py-5" id="services">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="section-header text-center pb-5">
          <h2>Swimming is natural and weightless, almost like flying.</h2>
          <p>Making waves, one stroke at a time.<br>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12 col-md-12 col-lg-4">
        <div class="card text-white text-center bg-dark">
          <div class="card-body mb-4">
           <i class="bi bi-droplet"></i>
            <h3 class="card-title">Liquid Life</h3>
            <p class="lead">Swimming is a fantastic exercise that keeps your body and mind in condition.
            <p><a href="features.php" class="btn btn-warning mt-3">Read More</a></p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-lg-4">
        <div class="card text-white text-center bg-dark pb-2">
          <div class="card-body mb-3">
          <i class="bi bi-droplet-fill"></i>
            <h3 class="card-title">The Swim Experience</h3>
            <p class="lead">Swimming is an art, and like any other art form, it takes practice and dedication to master.</p>
            <p><a href="features.php" class="btn btn-warning mt-3">Read More</a></p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-12 col-lg-4">
        <div class="card text-white text-center bg-dark pb-2">
          <div class="card-body mb-3">
          <i class="bi bi-droplet-half pb-3"></i>
            <h3 class="card-title">Swimming Symphony</h3>
            <p class="lead">Swimming is often compared to flying, as both activities provide a sense of weightlessness.</p>
            <p><a href="features.php" class="btn btn-warning mt-3">Read More</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section>
  
</section>
<section class="team section-padding py-5" id="team">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="section-header text-center pb-5">
          <h2>Swimming Club Founder and Assistances</h2>
          <p>Experienced founders provide guidance and support to members, helping them to improve their skills and techniques.<br></p>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12 col-md-6 col-lg-3">
        <div class="card text-center">
          <div class="card-body mb-1">
            <img alt="GWSC" class="img-fluid rounded-circle" src="images/people7.jpg">
            <h3 class="card-title py-2">John Wick</h3>
            <p class="card-text">He is responsible for securing funding and resources to support the club's activities and operations.</p><br>
            <p class="socials">
            <a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
            <a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
            <a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
            <a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a></p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-lg-3">
        <div class="card text-center">
          <div class="card-body mb-4">
            <img alt="GWSC" class="img-fluid rounded-circle" src="images/people8.jpg">
            <h3 class="card-title py-2">Ywa Mi</h3>
            <p class="card-text">She is responsible for attracting new members to the club and ensuring its growth.</p><br>
            <p class="socials">
            <a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
            <a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
            <a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
            <a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a></p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-lg-3">
        <div class="card text-center">
          <div class="card-body mb-4">
            <img alt="GWSC" class="img-fluid rounded-circle" src="images/people9.jpg">
            <h3 class="card-title py-2">Kyle</h3>
            <p class="card-text">He establishes relationships with stakeholders, including community organizations, government departments</p>
            <p class="socials">
            <a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
            <a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
            <a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
            <a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a></p>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-6 col-lg-3">
        <div class="card text-center">
          <div class="card-body mb-4">
            <img alt="GWSC" class="img-fluid rounded-circle" src="images/people11.jpg">
            <h3 class="card-title py-2">Smith</h3>
            <p class="card-text">He hires and manages staff, such as coaches and administrative personnel, to support the club's operations.</p>
            <p class="socials">
            <a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
            <a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
            <a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
            <a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


  <?php
require_once('footer.php');
?>
