<?php 
  session_start();
  include('db/dbconfig.php');
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GWSC Swimming</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    

</head>
<body>

      <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top bg-secondary">
        <div class="container">
        <i class="bi bi-signpost-split-fill"></i><a class="navbar-brand" href="#"><span class=".text-muted">GWSC</span></a>
          <a class="list-group-item" href="backend/index.php">
                    <?php
                        if(!empty($_SESSION['email']))
                        {
                    ?>
                        <a href="backend/logout.php" class="list-group-item">  <i class="bi bi-person-circle"></i> <?= $_SESSION['name']; ?></a>
                    <?php
                        }
                        else{
                        echo 'Login';
                        }
                    ?>

              </a> 
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
          aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="information.php">Information</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="service.php">Product</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="reviews.php">Reviews</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="features.php">Features</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="contact.php">Contact</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="attractions.php">Attractions</a>
              </li>
            </ul>
            <form class="d-flex" role="search" action="productbrowse.php" method="post">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"name="search">
              <button class="btn btn-outline-warning" type="submit" name="save">Search</button>
            </form>      
          </div>
        </div>
      </nav><br><br>