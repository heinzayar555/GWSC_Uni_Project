<?php
  require_once('header.php');
  require_once('db/dbconfig.php');
  $review =  $pdo_conn->prepare("SELECT * FROM review ORDER BY r_id");
  $review->execute();
  $review_result = $review->fetchAll();
?>
     
     <section class="information py-5">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-dark text-center">This is our review page.</h1>
			</div>			
		</div>
	</div>
</section>


<div class="container-fluid py-5">
 <div class="row row-cols-1 row-cols-md-3 g-4">
 <?php if(!empty($review_result)){
		foreach($review_result as $row) {
	
	?>
  <div class="col">
    <div class="card h-100">
    <img src="images/<?php echo $row['r_img'];?>" class="card-img-top" alt="review">
      <div class="card-body">
      <h5 class="card-title"><?php echo $row['r_name'];?></h5>
      <p class="card-text"><?php echo $row['r_msg'];?></p>
      </div>
      <div class="card-footer  text-center">
       <?php for($i=0; $i < $row['r_star']; $i++) {
          echo '<i class="text-dark bi bi-star-fill"></i>';
       }

       ?>
      </div>
    </div>
  </div>
  <?php
	}
}
	?>
 </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-12 ">
    <div class="review-form">
<div class="main-div col-12">
    <div class="panel">
   <h2>Review Form</h2>
   <p>Please enter your review and profile picture</p>
   </div>
    <form id="review"  action="create/review.php" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="r_name" id="inputName"  placeholder="Name">
        </div>
        <div class="form-group">
        <textarea id="" class="form-control" name="r_msg" cols="30" rows="10" placeholder="Message...."></textarea>
        </div>
        <div class="form-group">
            <input type="file" class="form-control" name="r_img" id="inputImage" placeholder="Image">
        </div>
        <div class="form-group">
            <input type="number" class="form-control" name="r_star" id="inputstar" placeholder="Star">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
    </div>
    </div>
  </div>
</div>
  <?php
require_once('footer.php');
?>
