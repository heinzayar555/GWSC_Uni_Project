<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('location:index.php');
} 
include('../db/dbconfig.php');
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $pdo_statement = $pdo_conn->prepare("SELECT * FROM users WHERE email='".$email."' AND pass='".$pass."'");
	$pdo_statement->execute();
	$result = $pdo_statement->fetchAll();
    if(!empty($result)) { 
        $_SESSION['name'] = $result[0]['name'];
        $_SESSION['email'] = $result[0]['email'];
        $_SESSION['type'] = $result[0]['type'];
        if ($result[0]['type'] == 0){
            header('location:dashboard.php');
        }else{
            header('location:../service.php');
        }
    }else{
        if(!isset($_SESSION['attempt'])){
            $_SESSION["attempt"]=0;
        }
        
        $_SESSION['attempt'] += 1;
        
        echo $_SESSION["attempt"];
        if($_SESSION['attempt'] >= 3){
            $_SESSION['attempt_again'] = time() + (1 *600);
            $_SESSION['msg'] = "Your Login is disabled";

        header('location:index.php?msg=disabled');
        }else{
            header('location:index.php?msg=error');
        }
    }
?>