<?php 
    include('../chklogin.php');
    include('../../db/dbconfig.php');

    $book_statement = $pdo_conn->prepare("SELECT * FROM book");
    $book_statement->execute();
    $book = $book_statement->fetchAll();
?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">


     <div class="container">
     <div class="row">
            <div class="col-md-12">    
                <h2 class="text-center">Bookings</h2>
                <a href="../dashboard.php" class=" bg-primary text-white p-2 text-decoration-none "><i class="fa fa-arrow-left"></i> Return Home </a>
            </div>
        </div>
    <div class="row col-md-12 col-md-offset-2 custyle mt-2">
    <table class="table table-striped custab">
    <thead>

        <tr>
            <th>Pitch Name</th>
            <th>Price</th>
            <th>Guest</th>
            <th>Check IN</th>
            <th>Check OUT</th>
            <th>Customer Name</th>
            <th>E-Mail</th>
            <th>Phone Number</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <?php   
                if(!empty($book)){
                foreach($book as $row){
            ?>
            <tr>
                <td><?= $row['p_name'];?></td>
                <td><?= $row['p_price'];?></td>
                <td><?= $row['person'];?></td>
                <td><?= $row['datein'];?></td>
                <td><?= $row['dateout'];?></td>
                <td><?= $row['username'];?></td>
                <td><?= $row['mail'];?></td>
                <td><?= $row['ph'];?></td>
                <td class="text-center"><a class='btn btn-info btn-xs' href="edit.php?id=<?php echo $row['id'];?>"><span class="fa fa-edit"></span> Edit</a> <a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Del</a></td>
            </tr>

            <?php
                }
                }
            ?>

    </table>
    </div>
</div>
</div>


