<?php
    $id = $_GET['id'];
    include('header.php');
    if(!empty($_SESSION['email'])){
    include('db/dbconfig.php');
    $product_statement = $pdo_conn->prepare("SELECT product.* FROM product WHERE id='".$id."'");
    $product_statement->execute();
    $product = $product_statement->fetch();

    $type_statement = $pdo_conn->prepare("SELECT * FROM type");
    $type_statement->execute();
    $type = $type_statement->fetchAll();    

    $msg = "";
    if(isset($_GET['msg'])){
        $msg = $_GET['msg'];
    }else{
        $msg = "";
    }

?>

<link rel="stylesheet" href="css/book.css">
<?php
                if($msg == "success")
                {
            ?>
            <div class="row">
                <div class="col-md-4 mx-auto  text-center mt-3">
                    <div class="alert alert-success" role="alert">
                        <strong>The Booking have been accepted!</strong>
                    </div>

                </div>
            </div>
        <?php
            }
        ?>
<div class="wrapper bg-white">
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
    <h4 class="tour-form-title text-center mt-3">Your Booking Details</h4>
</div>
        <form method="post" action="create/book.php">
                <?php
                    if(!empty($product)){
                ?>
                <div class="form-group d-sm-flex margin">
                <div class="form-group border-bottom d-flex align-items-center position-relative">
                    <input class="form-control" type="text" name="p_name" value="<?php echo $product['name'];?>" readonly> 
                </div>
                <div class="d-flex align-items-center flex-fill ms-sm-1 my-sm-0 my-4 border-bottom position-relative">
                <input class="form-control" type="number" name="p_price" value="<?php echo $product['price'];?>" readonly> 
                </div>
                </div>
                <?php
                    }
                ?>


                <?php
                    if(!empty($type)){
                    foreach($type as $col){
                        if(is_array($product)){
                    if($product['type_id'] == $col['id']){
                ?>
                <div class="form-group border-bottom d-flex align-items-center position-relative">
                <input type="text" class="form-control" id="pitch_type" name="pitch_type" value="<?php echo  $col['name'];?>" readonly>    
                            </div>                                 
                <?php
                    }           
                    }
                    }
                }
                ?>

                <div class="d-flex align-items-center flex-fill ms-sm-1 my-sm-0 my-4 border-bottom position-relative">
                <select class="form-control" name="person" required> 
                    <option value="" selected hidden>guests</option> 
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                </select> 
                </div>  
            <div class="form-group d-sm-flex margin">
                <div class="d-flex align-items-center flex-fill me-sm1 my-sm-0 border-bottom position-relative">
                    <input type="date" required placeholder="Depart Date" class="form-control" name="datein">
                    <div class="label" id="depart"></div>
                </div>
                <div class="d-flex align-items-center flex-fill ms-sm-1 my-sm-0 my-4 border-bottom position-relative">
                    <input type="date" required placeholder="Return Date" class="form-control" name="dateout">
                    <div class="label" id="return"></div>
                </div>
            </div>
            <div class="form-group border-bottom d-flex align-items-center position-relative">
                <input type="text" required placeholder="Name" class="form-control" name="username">
                <span class="fas fa-user text-muted"></span>
            </div>
            <div class="form-group border-bottom d-flex align-items-center position-relative">
                <input type="email" required placeholder="Email" class="form-control" name="mail">
                <span class="fa-solid fa-envelope text-muted"></span>
            </div>
            <div class="form-group border-bottom d-flex align-items-center position-relative">
                <input type="text" required placeholder="Phone" class="form-control" name="ph">
                <span class="fa-solid fa-mobile text-muted"></span>
            </div>
            <div class="form-group my-3">
                <button type="submit" class="btn btn-primary rounded-3 d-flex justify-content-center text-center p-2">Book Now</button>
                <a href="service.php" class="btn btn-danger mt-3 text-white">Cancel</a>
            </div>
        </form>

    </div>

    <?php
        }
        else{
            header('location:service-detail.php?id='.$id.'&msg=error');
        }
?>