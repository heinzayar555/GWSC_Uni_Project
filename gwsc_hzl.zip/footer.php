<section class="footer bg-secondary py-5">
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <h4 class="text-white">About GWSC</h4>
      <p class="text-white">A swimming club is a group of people who meet to participate in leisure or competitive swimming activities. Swimming activities, classes, 
                            and tournaments are normally available at the club for persons of all ages and experience levels.</p>
    </div>
    <div class="col-md-4">
      <h4 class="text-white">Useful links</h4>
      <ul class="text-white">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="index.php">Home</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="information.php">Information</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="availability.php">Availability</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="reviews.php">Reviews</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="features.php">Features</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="contact.php">Contact</a>
        </li>
        <li class="nav-item">
        <a class="nav-link" aria-current="page" href="attractions.php">Attractions</a>
        </li>
      </ul>
    </div>
    <div class="col-md-4">
      <h2 class="text-white">This is our Location</h2>
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26370649.06182039!2d-113.70425899266411!3d36.213411525842794!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited%20States!5e0!3m2!1sen!2smm!4v1676622922462!5m2!1sen!2smm" 
        width="100%" height="170" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
            <a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
            <a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
            <a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a>
    </div>
  </div>
</div>
</section>
<section class="copyright bg-dark">
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <p class="text-white text-center">&copy; 2023 Copyright. All rights reserved by Hein Zayar Lin</p>
      <?php include('counter.php');?>
    </div>
  </div>
</div>
</section>

<script src="js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js" integrity="sha512-STof4xm1wgkfm7heWqFJVn58Hm3EtS31XFaagaa8VMReCXAkQnJZ+jEy8PCC/iT18dFy95WcExNHFTqLyp72eQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>
