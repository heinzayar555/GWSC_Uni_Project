<?php
  require_once('header.php');
?>

<section class="information py-5">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-dark text-center">This is our attraction page.</h1>
        <p class="text-center">Find happiness in the waves, whether their man-made or courtesy of Mother Nature. 
          The epicenter for fun in the sun, Sauk plays host to several water parks, lakes, and rivers that are just 
          waiting to help you live every day like it’s the weekend.</p>
			</div>			
		</div>
	</div>
</section>

<div class="container-fluid py-5 bg-info">
  <div class="row">
    <div class="col-md-6">
      <div class="row">
        <div class="col-md-6">
 <img src="images/attraction5.jpg" style="width:100%; height: 80%;" class="mx-auto" alt="attraction place">
        </div>
        <div class="col-md-6">
          <h3>Minnewaska State Park Reserve, New York </h3>
<p>Minnewaska State Park Reserve is located on Shawangunk Ridge, more than 2,000 feet above sea level, and is surrounded by 
  mountainous terrain despite being just 94 miles from New York City.</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
    <div class="row">
        <div class="col-md-6">
 <img src="images/attraction6.jpg" style="width:100%; height: 100%" class="mx-auto" alt="attraction place">
        </div>
        <div class="col-md-6">
          <h3>Ozark–St. Francis National Forests, Arkansas </h3>
<p>Arkansas has a lot of beautiful landscape that is sometimes ignored. Nine beaches, several lakes and streams, and more than 1,000 
  miles of hiking trails may all be found within the 1.2 million acres of recreational area that make up the Ozark-St.</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>

<div class="container mt-5 mb-4">
	<div class="row">
		<div class="col-md-6 text-justify">
			<img src="images/indoor.jpg" class="img w-100 img-edit rounded shadow" alt="attraction place">
		</div>
		<div class="col-md-6 mt-5">
			<h2>Arizona: Kiwanis Recreation Center</h2>
			<p>Tempe's Kiwanis Recreation Center features an indoor, warm-water wave pool. The 3-foot waves come in eight patterns, and the pool 
        offers tube and raft rentals. Visitors can also try a 122-foot, double-spiral waterslide and enjoy lap swimming, open swim, or water
         fitness. Admission fees are $7 or less.</p>
		</div>
   
	</div>
</div>



<div class="container py-5">
  <div class="row">
  <div class="section-header text-center pb-5">
          <h2>Here are some attraction swimming place near the Go Wild Swimming</h2>
  </div>
    <div class="col-md-3"><img src="images/attraction1.jpg" class="figure-img img-fluid rounded rounded-circle" alt="Cinque Terre" width="200" height="156"></div>
    <div class="col-md-3"><img src="images/attraction2.jpg" class="figure-img img-fluid rounded rounded-circle" alt="Cinque Terre" width="190" height="136"></div>
    <div class="col-md-3"><img src="images/indoor2.jpg"     class="figure-img img-fluid rounded rounded-circle" alt="Cinque Terre"width="200" height="136"></div>
    <div class="col-md-3"><img src="images/indoor3.jpg"     class="figure-img img-fluid rounded rounded-circle" alt="Cinque Terre"width="200" height="136"></div>
  </div>
</div>

 
<?php
require_once('footer.php');
?>