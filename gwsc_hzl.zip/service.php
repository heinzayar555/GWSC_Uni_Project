<?php
  require_once('header.php');
  require_once('db/dbconfig.php');
  $product =  $pdo_conn->prepare("SELECT * FROM product");
  $product->execute();
  $product_result = $product->fetchAll();
?>

<section class="information py-5">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-dark text-center">Pitch Types and Availability</h1>
			</div>			
		</div>
	</div>
</section>

<section class="product py-5">
<div class="container-fluid">
  <h1 class="text-center">This is our products for you</h1>
  <div class="row">
    <?php
      if(!empty($product_result)){
        foreach($product_result as $product_row){
          
   
    ?>
    <div class="col-md-4 card-alg">
    <div class="card" style="width: 24rem;">
    <img src="images/<?php echo $product_row['image'];?>" class="card-img-top card-im" alt="...">
    <div class="card-body">
    <h5 class="card-title"><?php echo $product_row['name'];?></h5>
    <p class="card-text"><?php echo substr($product_row['description'], 0, 200) . "...";?></p>
    <p class="card-text">Price: $<?php echo $product_row['price'];?></p>
    <a href="service-detail.php?id=<?php echo $product_row['id'];?>" class="btn btn-primary">More Detail</a>
    <a href="book.php?id=<?php echo $product_row['id'];?>" class="btn btn-success">Book Now</a>
  </div>
</div>
</div>
<?php
        }
      }
?>
  </div>
</div>
</section>

<section id="about" class="about info-padding bg-light">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-12 col-12 py-5">
        <div class="about-img">
          <img src="images/g11.jpg" style="width:100%;height: 70%" class="mx-auto rounded" alt="">
        </div>
      </div>
      <div class="col-lg-4 col-md-12 col-12 ps-lg-5 mt-md-5">
        <div class="info-text">
          <h4 class="text-center">Relaxation after swimming</h4>
          <p>Dining and snack options could include a restaurant, cafe, and poolside bars. The description could highlight the menu items and special offers available.
            <br>Spa and relaxation areas could include hot tubs, saunas, and steam rooms. The description could highlight the benefits of these features and the recommended usage time.
          </p>
        </div>
      </div>
      <div class="col-lg-4 col-md-12 col-12 py-5">
        <div class="about-img">
            <img src="images/spa1.jpeg" style="width:100%;height: 70%" class="mx-auto rounded" alt="">
        </div>
      </div>
    </div>
  </div>
</section>

<?php
require_once('footer.php');
?>
