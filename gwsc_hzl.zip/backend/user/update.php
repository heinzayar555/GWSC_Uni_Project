<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];

    $type = $_POST['type'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $sql = $pdo_conn->prepare("UPDATE users SET type='".$type."',name='".$name."',email='".$email."',pass='".$pass."' WHERE id=".$id);
    $sql->execute();
    header('location:../dashboard.php');
?>