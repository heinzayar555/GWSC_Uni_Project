<?php
    require_once('../db/dbconfig.php');
    $p_name = $_POST['p_name'];
    $p_price = $_POST['p_price'];
    $person = $_POST['person'];
    $datein = $_POST['datein'];
    $dateout = $_POST['dateout'];
    $username = $_POST['username'];
    $mail = $_POST['mail'];
    $ph = $_POST['ph'];
    $pitch_type = $_POST['pitch_type'];


    $pdo_statement = "INSERT INTO book(p_name,p_price,person,datein,dateout,username,mail,ph,pitch_type) VALUES (:p_name,:p_price,:person,:datein,:dateout,:username,:mail,:ph,:pitch_type)";
    $pdo_statement = $pdo_conn->prepare($pdo_statement);
    $pdo_statement->execute(array(':p_name'=>$p_name,':p_price'=>$p_price,':person'=>$person,':datein'=>$datein,':dateout'=>$dateout,':username'=>$username,':mail'=>$mail,':ph'=>$ph,':pitch_type'=>$pitch_type));
    header('location:../book.php?id='.$id.'&msg=success');
?>