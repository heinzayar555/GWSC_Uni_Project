<?php
  require_once('header.php');
?>


<section>
<div class="contact-us py-5" id="contact">
 	<div class="container-fluid">
 		<div class="row justify-content-center">
 			<div class="col-xl-6 col-lg-8">
				<div class="title text-center">
					<h2>Contact Us for Swimming Camp Information</h2>
					<p>Please use the form below to send us your inquiries or feedback. Fill in your name, email address, and a brief message 
						describing your question or concern.</p>
				</div>
			</div>

		</div>
 		<div class="row py-3">
 			<div class="contact-details col-md-6 ">
 				<h3 class="mb-3">Contact Details</h3>
 				<p>"Thank you for showing interest in our services. One of our staff will call you as soon as possible once you fill out the 
					form below with your contact information and message. We appreciate you taking the time to get in touch with us."</p>
 				<ul class="contact-short-info mt-4">
 					<li class="mb-3">
 						<i class="tf-ion-ios-home"></i>
 						<span>Address: Street: 2438 6th Ave, Ketchikan</span>
 					</li>
 					<li class="mb-3">
 						<i class="tf-ion-android-phone-portrait"></i>
 						<span>Phone: (907) 225-9273</span>
 					</li>
 					<li class="mb-3">
 						<i class="tf-ion-android-globe"></i>
 						<span>Fax: 555-123-4567</span>
 					</li>
 					<li>
 						<i class="tf-ion-android-mail"></i>
 						<span>Email: gwscwebpage@gmail.com</span>
 					</li>
					<li>
					<div class="social-icon">		
					<a href="https://www.twitter.com"><i class="bi bi-twitter text-dark mx-1"></i></a>
					<a href="https://www.facebook.com"><i class="bi bi-facebook text-dark mx-1"></i></a>
					<a href="https://www.linkedin.com"><i class="bi bi-linkedin text-dark mx-1"></i></a>
					<a href="https://www.instagram.com"><i class="bi bi-instagram text-dark mx-1"></i></a>
 					</div>
					</li>
 				</ul>

				<!-- Button trigger modal -->
				<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">Terms and Conditions
				</button>

<!-- Modal -->
				<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" 
					aria-labelledby="staticBackdropLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="staticBackdropLabel">Our Terms and Conditions</h5>
						<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
					</div>
					<div class="modal-body">
					<p>For those who prefer swimming in undeveloped bodies of water, the Wild Swimming website offers a platform. The following terms
					and conditions must be carefully read and accepted before utilizing our services. You accept these terms and conditions as well
					as our privacy policy by accessing and using the Wild Swimming website. You shouldn't use our website or services if you disagree
					with these terms. <br><br>
					1. How to Use the Wild Swimming Website: Personal, non-commercial usage is the only use allowed for our website. You are not allowed
					 to use our website or its materials in any way that might harm or impair the performance of the website, whether it be for profit 
					or against the law.<br>
					2. User Conduct: You promise to abide by all relevant laws and regulations as well as our community rules when using the Wild Swimming
					 website. This includes refraining from engaging in any harmful, unlawful, or abusive behavior as well as refraining from submitting 
					 any false, misleading, or defamatory information. <br>
					3. Intellectual property: Wild Swimming or its licensors are the exclusive owners of all information and materials on the Wild Swimming 
					website. Without our prior written approval, you are not permitted to utilize any of the content or materials on our website. <br><br>
					You indicate that you have read, comprehended, and agreed to these terms and conditions by using the Wild Swimming website. We appreciate
					 you selecting GWSC as your go-to source for outdoor adventures.
					</p>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" data-bs-dismiss="modal">Understood</button>
					</div>
					</div>
				</div>
				</div>


 			</div>

 			<div class="contact-form col-md-6 ">
 				<form id="contact-form" method="post" role="form"   action="create/contact.php">
 					<div class="form-group mb-4">
 						<input type="text" placeholder="Your Name" class="form-control" name="c_name" id="name" required>
 					</div>

 					<div class="form-group mb-4">
 						<input type="email" placeholder="Your Email" class="form-control" name="c_email" id="email" required>
 					</div>
 					<div class="form-group mb-4">
 						<input type="text" placeholder="Your Phone Number" class="form-control" name="c_phone" id="email" required>
 					</div>

 					<div class="form-group mb-4">
 						<input type="text" placeholder="Subject" class="form-control" name="c_subject" id="subject" required>
 					</div>

 					<div class="form-group mb-4">
 						<textarea rows="6" placeholder="Message" class="form-control" name="c_message" id="message" required></textarea>
 					</div>
 					<div id="cf-submit">
 						<input type="submit" id="contact-submit" class="btn btn-transparent" value="Submit">
 					</div>

 				</form>
 			</div>
 		</div> 
 	</div> 
     </div> 
 </section> 

 
 <?php
require_once('footer.php');
?>