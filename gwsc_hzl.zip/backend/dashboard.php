<?php 
    include('chklogin.php');
    include('header.php');
    include('../db/dbconfig.php');

    $contact = $pdo_conn->prepare("SELECT Count(*) as countcontacts FROM contact");
    $contact->execute();
    $contact_result = $contact->fetchAll();

    $product = $pdo_conn->prepare("SELECT Count(*) as countproducts FROM product");
    $product->execute();
    $product_result = $product->fetchAll();

    $review = $pdo_conn->prepare("SELECT Count(*) as countreviews FROM review");
    $review->execute();
    $review_result = $review->fetchAll();

    $user_statement = $pdo_conn->prepare("SELECT Count(*) as countusers FROM users");
    $user_statement->execute();
    $user_result = $user_statement->fetchAll();

    $user_statement = $pdo_conn->prepare("SELECT * FROM users");
    $user_statement->execute();
    $user = $user_statement->fetchAll(); 

    $contact_statement = $pdo_conn->prepare("SELECT contact.* FROM contact ORDER BY c_id DESC LIMIT 10");
    $contact_statement->execute();
    $contt = $contact_statement->fetchAll();
?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
<link rel="stylesheet" href="../css/style.css">


<div class="jumbotron">
<div class="row">
        <div class="col-md-3">
            <div class="card border-info mx-sm-1 p-3">
                <div class="card border-info shadow text-info p-3 ms-2 my-card" ><span class="fa fa-home" aria-hidden="true"></span></div>
                <div class="text-info text-center mt-3"><h4>Pitch Type</h4></div>
                <div class="text-info text-center mt-2"><h1><?php echo $product_result[0]['countproducts'];?></h1></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-success mx-sm-1 p-3">
                <div class="card border-success shadow text-success p-3 ms-2 my-card"><span class="fa fa-inbox" aria-hidden="true"></span></div>
                <div class="text-success text-center mt-3"><h4>Inbox</h4></div>
                <div class="text-success text-center mt-2"><h1><?php echo $contact_result[0]['countcontacts'];?></h1></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-danger mx-sm-1 p-3">
                <div class="card border-danger shadow text-danger p-3 ms-2 my-card" ><span class="fa fa-sticky-note" aria-hidden="true"></span></div>
                <div class="text-danger text-center mt-3"><h4>Reviews</h4></div>
                <div class="text-danger text-center mt-2"><h1><?php echo $review_result[0]['countreviews'];?></h1></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-warning mx-sm-1 p-3">
                <div class="card border-warning shadow text-warning p-3 ms-2 my-card" ><span class="fa fa-user" aria-hidden="true"></span></div>
                <div class="text-warning text-center mt-3"><h4>Users</h4></div>
                <div class="text-warning text-center mt-2"><h1><?php echo $user_result[0]['countusers'];?></h1></div>
            </div>
        </div>
     </div>

     <div class="container">
    <div class="row col-md-12 col-md-offset-2 custyle mt-5">
    <table class="table table-striped custab">
    <thead>
    <p class="btn btn-primary btn-xs pull-right">User Accounts</p>
        <tr>
            <th>User Type</th>
            <th>Username</th>
            <th>Email</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <?php   
                if(!empty($user)){
                foreach($user as $rows){
            ?>
            <tr>
                <td><?= $rows['type'];?></td>
                <td><?= $rows['name'];?></td>
                <td><?= $rows['email'];?></td>
                <td class="text-center"><a class='btn btn-info btn-xs' href="user/edit.php?id=<?php echo $rows['id'];?>"><span class="fa fa-edit"></span> Edit</a> <a href="user/delete.php?id=<?php echo $rows['id'];?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Del</a></td>
            </tr>

            <?php
                }
                }
            ?>

    </table>
    </div>
</div>
</div>


     <div class="container">
    <div class="row col-md-12 col-md-offset-2 custyle mt-5">
    <table class="table table-striped custab">
    <thead>
    <p class="btn btn-primary btn-xs pull-right">Contacts</p>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Subject</th>
            <th class="text-center">Message</th>
        </tr>
    </thead>
    <?php   
                if(!empty($contt)){
                foreach($contt as $row){
            ?>
            <tr>
                <td><?= $row['c_name'];?></td>
                <td><?= $row['c_email'];?></td>
                <td><?= $row['c_phone'];?></td>
                <td><?= $row['c_subject'];?></td>
                <td><?= $row['c_message'];?></td>
                <td class="text-center"><a href="user/deletecontact.php?id=<?php echo $row['c_id'];?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Del</a></td>
            </tr>

            <?php
                }
                }
            ?>

    </table>
    </div>
</div>
</div>


