<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];

    $p_name = $_POST['p_name'];
    $p_price = $_POST['p_price'];
    $person = $_POST['person'];
    $datein = $_POST['datein'];
    $dateout = $_POST['dateout'];
    $username = $_POST['username'];
    $mail = $_POST['mail'];
    $ph = $_POST['ph'];
    $pitch_type = $_POST['pitch_type'];

    $sql = $pdo_conn->prepare("UPDATE book SET p_name='".$p_name."',p_price='".$p_price."',person='".$person."',datein='".$datein."',dateout='".$dateout."',username='".$username."',mail='".$mail."',ph='".$ph."',pitch_type='".$pitch_type."'WHERE id=".$id);
    $sql->execute();
    header('location:index.php');
?>