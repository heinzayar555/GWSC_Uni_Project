<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];

    $product_statement = $pdo_conn->prepare("SELECT * FROM book WHERE id=".$id);
    $product_statement->execute();
    $product = $product_statement->fetchAll();

	$type_statement = $pdo_conn->prepare("SELECT * FROM type");
	$type_statement->execute();
	$type = $type_statement->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Form</title>
    <link rel="stylesheet" href="../../css/crud.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.css' integrity='sha512-bR79Bg78Wmn33N5nvkEyg66hNg+xF/Q8NA8YABbj+4sBngYhv9P8eum19hdjYcY7vXk/vRkhM3v/ZndtgEXRWw==' crossorigin='anonymous'/>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php foreach ($product as $row) {
                ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <link href="https://fonts.googleapis.com/css?family=Oleo+Script:400,700" rel="stylesheet">
   	<link href="https://fonts.googleapis.com/css?family=Teko:400,700" rel="stylesheet">
   	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
<section id="contact">
			<div class="section-content">
				<h1 class="section-header">Book the product<span class="content-header wow fadeIn " data-wow-delay="0.2s" data-wow-duration="2s">you want here.</span></h1>
			</div>
			<div class="contact-section">
			<div class="container">
				<form action="update.php?id=<?php echo $row['id'];?>" method="post">
					<div class="col-md-6 form-line">
			  			<div class="form-group">
			  				<label for="exampleInputUsername">Pitch Name</label>
                              <input type="name" class="form-control" placeholder="Update Pitch Name" name="p_name" value="<?php echo $row['p_name'];?>">
				  		</div>
				  		<div class="form-group">
					    	<label for="exampleInputPrice">Price</label>
                            <input type="float" class="form-control" placeholder="Update Price" name="p_price" value="<?php echo $row['p_price'];?>">
					  	</div>	
				  		<div class="form-group">
					    	<label for="exampleInputRating">Guests</label>
                            <input type="number" class="form-control" placeholder="Update Number of Guests" name="person" value="<?php echo $row['person'];?>">
					  	</div>	
					  	<div class="form-group">
                            <label for="type" class="form-label">Pitch Type</label>
                        <select name="pitch_type" class="form-control" id="">
                        <?php 
                                foreach($type as $col){
                            ?>
                                    <option value="<?php echo $col['id']; ?>"  <?php echo ($col['id'] == $row['pitch_type']) ? "selected" : ""; ?>>      <?php echo $col['name'];?>      </option>

                            <?php
                                }
                            
                            ?>
                        </select>
			  			</div>
						  <div class="form-group">
					    	<label for="name">Customer Name</label>
					    	<input type="text" class="form-control" placeholder="Update Customer Name" name="username" value="<?php echo $row['username'];?>">
			  			</div>
			  		</div>

			  		<div class="col-md-6">
					  <div class="form-group">
					    	<label for="Image">Check IN</label>
					    	<input type="date" class="form-control" placeholder="Update Check In Date" name="datein" value="<?php echo $row['datein'];?>">
			  			</div>
					  <div class="form-group">
					    	<label for="Image">Check OUT</label>
					    	<input type="date" class="form-control" placeholder="Update Check In Date" name="dateout" value="<?php echo $row['dateout'];?>">
			  			</div>
					  <div class="form-group">
					    	<label for="email">Email Address</label>
					    	<input type="email" class="form-control" placeholder="Update Email Address" name="mail" value="<?php echo $row['mail'];?>">
			  			</div>
					  <div class="form-group">
					    	<label for="Image">Phone Number</label>
					    	<input type="text" class="form-control" placeholder="Update Phone Number" name="ph" value="<?php echo $row['ph'];?>">
			  			</div>
			  		</div>

			  			<div>
			  				<button type="submit" value="save" class="btn btn-default submit text-center ms-3"><i class="fa fa-paper-plane" aria-hidden="true">Submit</i></button>
                              <a href="index.php" class=" ms-2 btn btn-danger text-white px-3 text-decoration-none">Cancel</a>
			  			</div>
			  			
					</div>
				</form>
				<?php
                }
                ?>
			</div>
		</section>

</body>
</html>