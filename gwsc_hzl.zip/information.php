<?php
  require_once('header.php');

?>

<section class="information py-5">
    <div class="container">
		<div class="row">
			<div class="col-md-12">
				<h1 class="text-dark text-center">This is our information page.</h1>
			</div>			
		</div>
	</div>
</section>

<div class="container py-5">
	<div class="row">
		<div class="col-md-6 text-justify">
			<img src="images/info1.jpg" class="img w-100 h-75 rounded shadow" alt="GWSC">
		</div>
		<div class="col-md-6 mt-5">
			<h2>Another Attraction Place</h2>
			<p>The waves in the water may provide for an exciting experience while giving a fun and demanding workout. 
                Yet it's crucial to be mindful of hazards including currents, tides, and aquatic animals.
			</p>
		</div>
	</div>

	<div class="row">
		<div class="col-md-6 mt-5">
		<h2>Another Attraction Place</h2>
			<p>In rivers and streams, where the water is naturally filtered and circulated by the flow of the water, 
                natural pools are frequently produced. These pools could contain rapids or rivers, making swimming there 
                interesting and invigorating.
			</p>
		</div>
		<div class="col-md-6">
		<img src="images/info2.jpg" class="img w-100 h-75 rounded shadow" alt="GWSC">
		</div>
	</div>
</div>

<div class="container-fluid py-5 bg-secondary">
  <div class="row">
    <div class="col-md-6">
      <div class="row">
        <div class="col-md-6">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153517.6114266566!2d-113.79016270682557!3d39.47820529685182!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x874c6bc78f13f9cd%3A0xbddf4aa56cd7463f!2sUtah%2C%20USA!5e0!3m2!1sen!2smm!4v1676525479544!5m2!1sen!2smm" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-md-6">
		<h2>Location 1 for our club</h2>
            <p class="text-white">Utah is known for its many beautiful natural features, and there are several natural hot springs and pools throughout the state that are popular tourist destinations.</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
    <div class="row">
        <div class="col-md-6">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d423286.2740321382!2d-118.69191821398664!3d34.02016131165962!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c75ddc27da13%3A0xe22fdf6f254608f4!2sLos%20Angeles%2C%20CA%2C%20USA!5e0!3m2!1sen!2smm!4v1676525857314!5m2!1sen!2smm" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-md-6">
		<h2>Location 2 for our club</h2>
            <p class="text-white">Los Angeles pool is open to the public and features a shallow end for kids and non-swimmers, as well as a deeper end for more experienced swimmers.</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>

<div class="container-fluid py-5 bg-secondary">
  <div class="row">
    <div class="col-md-6">
      <div class="row">
        <div class="col-md-6">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d99101.32187035399!2d-108.71336169247017!3d39.085604025216746!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8746d6e322e77057%3A0xcc63f451cebf7c56!2sGrand%20Junction%2C%20CO%2C%20USA!5e0!3m2!1sen!2smm!4v1676525917717!5m2!1sen!2smm" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-md-6">
			<h2>Location 3 for our club</h2>
                <p class="text-white">Grand Junction pool features a diving board, a water slide, and a lazy river, making it a great place for families and kids to enjoy.</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
    <div class="row">
        <div class="col-md-6">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d220449.90094610414!2d-98.0428373690097!3d30.307447528213373!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8644b599a0cc032f%3A0x5d9b464bd469d57a!2sAustin%2C%20TX%2C%20USA!5e0!3m2!1sen!2smm!4v1676525969279!5m2!1sen!2smm" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="col-md-6">
		<h2>Location 4 for our club</h2>
            <p class="text-white">Austin water is clear and cool, and the pool is surrounded by lush greenery and wildlife, making it a great place to relax and enjoy the natural beauty of Austin.</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>

<div class="container-fluid bg-warning py-5">
    <div class="row">
        <div class="col-md-4">
        <script type="text/javascript"> 
                <!-- 
                rssfeed_url = new Array(); 
                rssfeed_url[0]="https://www.buzzfeed.com/world.xml";  
                rssfeed_frame_width="380"; 
                rssfeed_frame_height="250"; 
                rssfeed_scroll="on"; 
                rssfeed_scroll_step="6"; 
                rssfeed_scroll_bar="off"; 
                rssfeed_target="_blank"; 
                rssfeed_font_size="12"; 
                rssfeed_font_face=""; 
                rssfeed_border="on"; 
                rssfeed_css_url=""; 
                rssfeed_title="on"; 
                rssfeed_title_name=""; 
                rssfeed_title_bgcolor="#3366ff"; 
                rssfeed_title_color="#fff"; 
                rssfeed_title_bgimage=""; 
                rssfeed_footer="off"; 
                rssfeed_footer_name="rss feed"; 
                rssfeed_footer_bgcolor="#fff"; 
                rssfeed_footer_color="#333"; 
                rssfeed_footer_bgimage=""; 
                rssfeed_item_title_length="50"; 
                rssfeed_item_title_color="#666"; 
                rssfeed_item_bgcolor="#fff"; 
                rssfeed_item_bgimage=""; 
                rssfeed_item_border_bottom="on"; 
                rssfeed_item_source_icon="off"; 
                rssfeed_item_date="off"; 
                rssfeed_item_description="on"; 
                rssfeed_item_description_length="120"; 
                rssfeed_item_description_color="#666"; 
                rssfeed_item_description_link_color="#333"; 
                rssfeed_item_description_tag="off"; 
                rssfeed_no_items="0"; 
                rssfeed_cache = "5938d473aa31df41e108e442c45fbb84"; 
                </script> 
                <script type="text/javascript" src="//feed.surfing-waves.com/js/rss-feed.js"></script> 
                <div class="text-success" style="color:#ccc;font-size:10px; text-align:right; width:380px;">powered by <a href="https://surfing-waves.com" class="text-primary" rel="noopener" target="_blank" style="color:#ccc;">Surfing Waves</a>
				</div> 
        </div>
        <div class="col-md-4">
        <script type="text/javascript"> 
                <!-- 
                rssfeed_url = new Array(); 
                rssfeed_url[0]="https://www.buzzfeed.com/world.xml";  
                rssfeed_frame_width="380"; 
                rssfeed_frame_height="250"; 
                rssfeed_scroll="on"; 
                rssfeed_scroll_step="6"; 
                rssfeed_scroll_bar="off"; 
                rssfeed_target="_blank"; 
                rssfeed_font_size="12"; 
                rssfeed_font_face=""; 
                rssfeed_border="on"; 
                rssfeed_css_url=""; 
                rssfeed_title="on"; 
                rssfeed_title_name=""; 
                rssfeed_title_bgcolor="#3366ff"; 
                rssfeed_title_color="#fff"; 
                rssfeed_title_bgimage=""; 
                rssfeed_footer="off"; 
                rssfeed_footer_name="rss feed"; 
                rssfeed_footer_bgcolor="#fff"; 
                rssfeed_footer_color="#333"; 
                rssfeed_footer_bgimage=""; 
                rssfeed_item_title_length="50"; 
                rssfeed_item_title_color="#666"; 
                rssfeed_item_bgcolor="#fff"; 
                rssfeed_item_bgimage=""; 
                rssfeed_item_border_bottom="on"; 
                rssfeed_item_source_icon="off"; 
                rssfeed_item_date="off"; 
                rssfeed_item_description="on"; 
                rssfeed_item_description_length="120"; 
                rssfeed_item_description_color="#666"; 
                rssfeed_item_description_link_color="#333"; 
                rssfeed_item_description_tag="off"; 
                rssfeed_no_items="0"; 
                rssfeed_cache = "5938d473aa31df41e108e442c45fbb84"; 
                </script> 
                <script type="text/javascript" src="//feed.surfing-waves.com/js/rss-feed.js"></script> 
                <div class="text-success" style="color:#ccc;font-size:10px; text-align:right; width:380px;">powered by <a href="https://surfing-waves.com" class="text-primary" rel="noopener" target="_blank" style="color:#ccc;">Surfing Waves</a>
				</div> 
        </div>
        <div class="col-md-4">
        <script type="text/javascript"> 
                <!-- 
                rssfeed_url = new Array(); 
                rssfeed_url[0]="https://www.buzzfeed.com/world.xml";  
                rssfeed_frame_width="380"; 
                rssfeed_frame_height="250"; 
                rssfeed_scroll="on"; 
                rssfeed_scroll_step="6"; 
                rssfeed_scroll_bar="off"; 
                rssfeed_target="_blank"; 
                rssfeed_font_size="12"; 
                rssfeed_font_face=""; 
                rssfeed_border="on"; 
                rssfeed_css_url=""; 
                rssfeed_title="on"; 
                rssfeed_title_name=""; 
                rssfeed_title_bgcolor="#3366ff"; 
                rssfeed_title_color="#fff"; 
                rssfeed_title_bgimage=""; 
                rssfeed_footer="off"; 
                rssfeed_footer_name="rss feed"; 
                rssfeed_footer_bgcolor="#fff"; 
                rssfeed_footer_color="#333"; 
                rssfeed_footer_bgimage=""; 
                rssfeed_item_title_length="50"; 
                rssfeed_item_title_color="#666"; 
                rssfeed_item_bgcolor="#fff"; 
                rssfeed_item_bgimage=""; 
                rssfeed_item_border_bottom="on"; 
                rssfeed_item_source_icon="off"; 
                rssfeed_item_date="off"; 
                rssfeed_item_description="on"; 
                rssfeed_item_description_length="120"; 
                rssfeed_item_description_color="#666"; 
                rssfeed_item_description_link_color="#333"; 
                rssfeed_item_description_tag="off"; 
                rssfeed_no_items="0"; 
                rssfeed_cache = "5938d473aa31df41e108e442c45fbb84"; 
                </script> 
                <script type="text/javascript" src="//feed.surfing-waves.com/js/rss-feed.js"></script> 
                <div class="text-success" style="color:#ccc;font-size:10px; text-align:right; width:380px;">powered by <a href="https://surfing-waves.com" class="text-primary" rel="noopener" target="_blank" style="color:#ccc;">Surfing Waves</a>
				</div> 
        </div>
        </div>
    </div>
</div>



<section id="feature" class="sec-padding sec-dark py-5">
        <div class="container">
            <div class="row row-no-padding">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>User-friendly interface and navigation</h5>
                            <p>A user-friendly interface should have a simple and intuitive layout, with clear and concise text, and easy-to-use navigation menus.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>Responsive design</h5>
                            <p>A responsive design adapts the layout and appearance of the website to fit different screen sizes and devices, such as desktops, laptops, tablets, and smartphones.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="feature-design">
                        <h3>functionality of GWSC</h3>
                        <p>Search functionality enables users to search the website's content by keyword or phrase, to find what they are looking for more quickly and easily.</p>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>Fast loading speed</h5>
                            <p>A website with fast loading speed will load quickly and efficiently, providing a better user experience and helping to keep visitors on the site.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>Analytics and tracking</h5>
                            <p>Analytics and tracking allow website owners to gather data about website visitors and their behavior, to gain insights into their audience and improve the website.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>Easy contact and feedback options</h5>
                            <p>Contact and feedback options, such as contact forms and live chat, allow users to get in touch with the website owners and provide feedback.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="feature-layout">
                        <div class="feature-layout-item">

                            <h5>Multilingual support</h5>
                            <p>Multilingual support allows the website to be viewed in multiple languages, to reach a wider global audience.</p>
                        </div>
                        <div class="feature-layout-overlay"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php
require_once('footer.php');
?>
