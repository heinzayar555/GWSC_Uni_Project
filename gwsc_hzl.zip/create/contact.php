<?php
    require_once('../db/dbconfig.php');
    $name = $_POST['c_name'];
    $email = $_POST['c_email'];
    $phone = $_POST['c_phone'];
    $subject = $_POST['c_subject'];
    $message = $_POST['c_message'];

    $pdo_statement = "INSERT INTO contact(c_name,c_email,c_phone,c_subject,c_message) VALUES (:c_name,:c_email,:c_phone,:c_subject,:c_message)";
    $pdo_statement = $pdo_conn->prepare($pdo_statement);
    $pdo_statement->execute(array(':c_name'=>$name,':c_email'=>$email,':c_phone'=>$phone,':c_subject'=>$subject,':c_message'=>$message));
    header('location:../contact.php');
?>