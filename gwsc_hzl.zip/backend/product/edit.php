<?php
    require_once('../../db/dbconfig.php');
    $id = $_GET['id'];

    $product_statement = $pdo_conn->prepare("SELECT * FROM product WHERE id=".$id);
    $product_statement->execute();
    $product = $product_statement->fetchAll();

    $type_statement = $pdo_conn->prepare("SELECT * FROM type");
    $type_statement->execute();
    $type = $type_statement->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Form</title>
    <link rel="stylesheet" href="../../css/crud.css">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/css/bootstrap.css' integrity='sha512-bR79Bg78Wmn33N5nvkEyg66hNg+xF/Q8NA8YABbj+4sBngYhv9P8eum19hdjYcY7vXk/vRkhM3v/ZndtgEXRWw==' crossorigin='anonymous'/>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php foreach ($product as $row) {
                ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>


    <link href="https://fonts.googleapis.com/css?family=Oleo+Script:400,700" rel="stylesheet">
   	<link href="https://fonts.googleapis.com/css?family=Teko:400,700" rel="stylesheet">
   	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  
<section id="contact">
			<div class="section-content">
				<h1 class="section-header">Order the product<span class="content-header wow fadeIn " data-wow-delay="0.2s" data-wow-duration="2s"> You want here</span></h1>
				<h3>Our product is the top choice for those who value quality and reliability</h3>
			</div>
			<div class="contact-section">
			<div class="container">
				<form action="update.php?id=<?php echo $row['id'];?>" method="post" enctype="multipart/form-data">
					<div class="col-md-6 form-line">
			  			<div class="form-group">
			  				<label for="exampleInputUsername">Name</label>
                              <input type="name" class="form-control" placeholder="Insert your Name" name="name" value="<?php echo $row['name'];?>">
				  		</div>
				  		<div class="form-group">
					    	<label for="exampleInputPrice">Price</label>
                            <input type="float" class="form-control" placeholder="Enter Price"name="price" value="<?php echo $row['price'];?>">
					  	</div>	
				  		<div class="form-group">
					    	<label for="exampleInputRating">Product Rating</label>
                            <input type="number" class="form-control" placeholder="Enter Product Rating"name="star" value="<?php echo $row['star'];?>">
					  	</div>	
					  	<div class="form-group">
                            <label for="type" class="form-label">Product Type</label>
                        <select name="type_id" class="form-control" id="">
                        <?php 
                                foreach($type as $col){
                            ?>
                                    <option value="<?php echo $col['id']; ?>"  <?php echo ($col['id'] == $row['type_id']) ? "selected" : ""; ?>>      <?php echo $col['name'];?>      </option>

                            <?php
                                }
                            
                            ?>
                        </select>
			  			</div>
					  	<div class="form-group">
					    	<label for="Image">Image</label>
					    	<input type="file" class="form-control" placeholder="Enter Image Name" name="image" value="<?php echo $row['image'];?>">
			  			</div>
			  		</div>
			  		<div class="col-md-6">
			  			<div class="form-group">
			  				<label for ="description"> Description</label>
                              <textarea name="description" id="description" class="form-control" placeholder="Write about the Product"><?php echo $row['description'];?></textarea>
			  			</div>
			  			<div>

			  				<button type="submit" value="save" class="btn btn-default submit text-center"><i class="fa fa-paper-plane" aria-hidden="true">Submit</i></button>
                              <a href="index.php" class=" ms-2 btn btn-danger text-white px-3 text-decoration-none">Cancel</a>
			  			</div>
			  			
					</div>
				</form>
				<?php
                }
                ?>
			</div>
		</section>

</body>
</html>